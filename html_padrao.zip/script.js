// Isto aqui vai ser substituido pelo script
const DOMINIO = "{{DOMINIO}}";
function getUrlParameters() {
  const params = new URLSearchParams(window.location.search);
  const result = {};
  for (const [key, value] of params.entries()) {
    result[key] = value;
  }
  return result;
}

/**
* Retorna algumas informações úteis.
* Eis um exemplo:
* { CODUSU_LOG: "0", HOJE: "2021-03-02 00:00:00.0", CODVEN_LOG: "0", INICIO_MES: "2021-03-01 00:00:00.0", AGORA: "2021-03-02 12:00:33.838", CODGRU_LOG: "2" }
*/
async function parametros() {
  const parser = new DOMParser();
  const nugdg = getUrlParameters()["nuGdg"]
  const infoComponente = await fetch("https://" + DOMINIO + "/mge/service.sbr?serviceName=DynaGadgetBuilderSP.getGadgetInfo", {
    "credentials": "include",
    "headers": {
      "Content-Type": "text/xml; charset=utf-8",
    },
    "body": "<serviceRequest serviceName=\"DynaGadgetBuilderSP.getGadgetInfo\"><requestBody><parameters NUGADGET=\"" + nugdg + "\"/><clientEventList/></requestBody></serviceRequest>",
    "method": "POST",
  }).then(r => r.text());
  const infoXml = parser.parseFromString(infoComponente, "application/xml")
  const idPrimeiroNivel = infoXml.getElementsByTagName("gadget")[0].getAttribute("first-level-id")
  const xmlCru = await fetch("https://" + DOMINIO + "/mge/service.sbr?serviceName=DynaGadgetBuilderSP.resolveGadgetLevel", {
    "credentials": "include",
    "headers": {
      "Content-Type": "text/xml; charset=utf-8",
    },
    "body": "<serviceRequest serviceName=\"DynaGadgetBuilderSP.resolveGadgetLevel\"><requestBody><parameters NUGADGET=\"" + nugdg + "\" LEVEL-ID=\"" + idPrimeiroNivel + "\" LEVEL-PATH=\"" + idPrimeiroNivel + "\" REPLACE-TAG=\"true\" DATE-UTC=\"true\" APPMODE=\"false\" EVOCARD=\"false\"><prompt-parameters/><onclick-parameters/></parameters><clientEventList/></requestBody></serviceRequest>",
    "method": "POST",
  }).then(r => r.text());
  const xmlDoc = parser.parseFromString(xmlCru, "application/xml");
  const parametros = Array.from(xmlDoc.getElementsByTagName("params")[0].attributes).reduce((acc, it) => ({...acc, [it.name]: it.value}), {})
  return parametros
}
function getCookie(name) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(';').shift();
}

/**
* Realiza uma consulta no banco de dados e retorna uma lista de objetos
* no formato [{"COLUNA1": "VALOR1", "COLUNA2": "VALOR2"}]
*/
async function consulta(q) {
  const xmlCru = await fetch("https://" + DOMINIO + "/mge/service.sbr?serviceName=ExecQuerySP.execQuery", {
    "headers": {
      "content-type": "text/xml; charset=UTF-8",
    },
    "body": "<serviceRequest serviceName=\"ExecQuerySP.execQuery\"><requestBody><querydata query=\"" + q + "\"><config name=\"maxRows\" value=\"-1\"/></querydata><clientEventList/></requestBody></serviceRequest>",
    "method": "POST",
    "credentials": "include"
  }).then(r => r.text());
  if (xmlCru.includes("queryExecResult") && xmlCru.includes("ERRO")) {
    console.log(q + "\n" + xmlCru)
    throw new Error("Deu ruim")
  }
  const parser = new DOMParser();
  const xmlDoc = parser.parseFromString(xmlCru, "application/xml");
  const linhas = Array.from(xmlDoc.getElementsByTagName("line")).map((linha) => {
    const colunas = linha.getElementsByTagName("column");
    const resultado = {};
    for (let coluna of colunas) {
      const valor = coluna.getAttribute("value");
      const chave = coluna.getAttribute("name");
      resultado[chave] = valor;
    }
    return resultado;
  }
  );
  return linhas;
}
/**
* Abre uma pagina dentro do Sankhya-W.
* 
* - Se o resourceID nao existir, o sistema informara que a tela nao existe.
* - Se as chaves primarias nao forem informadas, a tela sera aberta na pagina inicial.
* - Se existirem chaves primarias, mas nao forem encontradas, a tela ssera aberta como visualizacao de um registro vazio (para inclusao)
* - Se existirem chaves primarias e forem encontradas, a tela sera aberta no registro encontrado.
* 
* @param { String } resourceID      ID do recurso a ser aberto
* @param { Object } chavesPrimarias Chaves de identificacao do registro
* 
* @example JX.abrirPagina ('br.com.sankhya.core.cad.marcas', { CODIGO: 999 });
* Inspirado em https://github.com/wansleynery/SankhyaJX
*/
function abrirPagina(resourceID, chavesPrimarias) {

  let url = `https://${DOMINIO}/mge/system.jsp#app/`;
  url += btoa(resourceID) + "/";
  if (chavesPrimarias) {

    let body = {};

    Object.keys(chavesPrimarias).forEach(function (chave) {
      body[chave] = isNaN(chavesPrimarias[chave])
        ? String(chavesPrimarias[chave])
        : Number(chavesPrimarias[chave])
    });

    url += btoa(JSON.stringify(body)) + "/";
  }

  Object.assign(document.createElement('a'), {
    target: '_top',
    href: url
  }).click();
}

console.log("Funcionou")
